            <?php
            include 'DBConnect.php';
            $Origin = $_GET["Origin"];
	        $Destination = $_GET["Destination"];
            $CurrentDate = date("Y-m-d");
            $selectquery = "SELECT * FROM schedule JOIN bus on schedule.BusId = bus.BusId WHERE schedule.Origin = '$Origin' AND schedule.Destination = '$Destination' AND schedule.Dep_Date > '$CurrentDate'";

            $query = mysqli_query($myconn,$selectquery);

            $nums = mysqli_num_rows($query);

            echo "
            <div class='detailsReservation'>
            <div class='recentReservation'>
                <div class='cardHeader'>
                    <h2>Available Buses</h2>
                </div>
            <table>
            <thead>
                <tr>
                    <th>Origin</th>
                    <th>Destination</th>
                    <th>Departure</th>
                    <th>Fare</th>
                    <th>Date</th>
                    <th>Available Seats</th>
                    <th>Operation</th>
                </tr>
            </thead>
            <tbody>";

            while($res = mysqli_fetch_array($query)){

                $id = $res['ScheduleId'];
                $myquery = "SELECT COUNT(SeatNo) as 'Allocated' FROM reservation join schedule on reservation.ScheduleId = schedule.ScheduleId WHERE schedule.ScheduleId = $id";
                $myresult = mysqli_query($myconn,$myquery);
                $res1 = mysqli_fetch_array($myresult);

                $available = $res['TotalSeats'] - $res1['Allocated'];

                echo"
                <tr>
                    <td>".$res['Origin']."</td>
                    <td>".$res['Destination']."</td>
                    <td>".$res['Departure_time']."</td>
                    <td>".$res['Fare']."</td>
                    <td>".$res['Dep_Date']."</td>
                    <td>".$available."</td>
                    <td><form method='get'>
                    <input type='hidden' name='schedule' id='schedule' value=". $res['ScheduleId'] .">
                    <input type='number' name='seats' min='1' value='' id='seats' placeholder='Number of seats'>
                    <input type='button' name='submit' onclick='ReserveSeat();' value='Book'>
                </form></td>
                    </tr>";
                }
                echo"
                </tbody>
                </table>
                </div>
                </div>";
                
                ?>
                <!-- <td><a href='javascript:SearchRouteOne(" . $res['ScheduleId'] . ")' data-toggle='tooltip' data-placement='buttom' title='BOOK SEAT'></title></data-toggle><img src='https://img.icons8.com/fluency/48/000000/add-ticket.png'/></a></td> -->
