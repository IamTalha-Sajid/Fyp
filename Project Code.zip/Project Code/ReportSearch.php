<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }

        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }

        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }

        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
    </style>
</head>

</html>
<?php
include 'DBConnect.php';

$selectquery = $_GET["query"];

$query = mysqli_query($myconn, $selectquery);

$nums = mysqli_num_rows($query);
echo "
            <div class='detailsReservation'>
            <div class='recentReservation'>
                <div class='cardHeader'>
                    <h2>RESERVATION REPORT</h2>
                    
                </div>
            <table class='styled-table'>
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Origin</th>
                    <th>Destination</th>
                    <th>Seat Number</th>
                    <th>BusNo</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>";

while ($res = mysqli_fetch_array($query)) {

    echo "
                <tr>
                    <td>" . $res['UserName'] . "</td>
                    <td>" . $res['Origin'] . "</td>
                    <td>" . $res['Destination'] . "</td>
                    <td>" . $res['SeatNo'] . "</td>
                    <td>" . $res['BusNo'] . "</td>
                    <td>" . $res['Dep_Date'] . "</td>
                </tr>";
}
echo "
            </tbody>
        </table>
        </div>
    </div>";

?>